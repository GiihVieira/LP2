using Microsoft.VisualBasic;
using System.Collections;

namespace PTesteLoop
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sariToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exerc�cio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int numeroEntrada;
            string[] numeros = new string[20];
            string saida = "";

            for (int i = 0; i < numeros.Length; i++)
            {
                if (!int.TryParse(Interaction.InputBox("Digite um n�mero: ", "Reverter Sequ�ncia N�merica"),
                    out numeroEntrada))
                {
                    MessageBox.Show("Digite um n�mero v�lido!");
                    i--;
                }
                else
                {
                    numeros[i] = numeroEntrada.ToString();
                }
            }

            Array.Reverse(numeros);

            for (int i = 0; i < numeros.Length; i++)
            {
                if (i != numeros.Length - 1)
                {
                    saida = saida + numeros[i] + ", ";
                }
                else
                {
                    saida = saida + numeros[i];
                }
            }

            MessageBox.Show($"Sequ�ncia de N�meros Inversa: {saida}");
        }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string saida = "";
            ArrayList Alunos = new ArrayList { "Ana" , "Andr�", "D�bora",
                                             "Jo�o", "Janete", "Ot�vio",
                                             "Marcelo", "Pedro", "Thais" };
            for (int j = 0; j < 2; j++)
            {
                if (j == 0)
                {
                    for (int i = 0; i < Alunos.Count; i++)
                    {
                        if (i != Alunos.Count - 1)
                        {
                            saida = saida + Alunos[i] + ", ";
                        }
                        else
                        {
                            saida = saida + Alunos[i];
                        }
                    }
                    MessageBox.Show($"Lista de Alunos: {saida}");
                }
                else
                {
                    Alunos.Remove("Ot�vio");
                    saida = "";
                    for (int i = 0; i < Alunos.Count; i++)
                    {
                        if (i != Alunos.Count - 1)
                        {
                            saida = saida + Alunos[i] + ", ";
                        }
                        else
                        {
                            saida = saida + Alunos[i];
                        }
                    }
                    MessageBox.Show($"Lista de Alunos sem o aluno Ot�vio: {saida}");
                }
            }
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string saida = "";
            double nota, soma;
            double[,] notasAlunos = new double[3, 20];
            double[] mediaAlunos = new double[20];

            // Entrada das notas de cada aluno e gera as m�dias
            for (int i = 0; i < 20; i++)
            {
                soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    if (!Double.TryParse(Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ", "M�dias dos Alunos"),
                        out nota) || nota > 10 || nota < 0)
                    {
                        MessageBox.Show("Digite uma nota v�lida!");
                        j--;
                    }
                    else
                    {
                        soma += nota;
                        notasAlunos[j, i] = nota;
                    }
                }
                mediaAlunos[i] = soma / 3;
            }

            // Print de sa�da
            for (int i = 0; i < 20; i++)
            {
                saida += $"Aluno {i + 1}, m�dia: {mediaAlunos[i].ToString("N1")} \n";
            }

            MessageBox.Show(saida);
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                // Chama o Form frmExercicio4 para a frente
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 objfrm4 = new frmExercicio4();
                objfrm4.MdiParent = this; // Deixa o form4 ancorado no form Principal
                objfrm4.WindowState = FormWindowState.Maximized;
                objfrm4.Show();
            }
        }

        private void exerc�cio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                // Chama o Form frmExercicio5 para a frente
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 objfrm5 = new frmExercicio5();
                objfrm5.MdiParent = this; // Deixa o form5 ancorado no form Principal
                objfrm5.WindowState = FormWindowState.Maximized;
                objfrm5.Show();
            }
        }
    }
}
