﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double vlrRaio;
                
            if (!double.TryParse(txtRaio.Text, out vlrRaio)) //Função TryParse() tenta converter um string do txtbox em outro tipo de dado, nesse caso um dado do tipo double
            {
                MessageBox.Show("Raio inválido!");
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double vlrAltura;

            if(!double.TryParse(txtAltura.Text, out vlrAltura))
            {
                MessageBox.Show("Altura inválida!");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vlrRaio, vlrAltura, volume;

            if ((!double.TryParse(txtRaio.Text, out vlrRaio)) || (!double.TryParse(txtAltura.Text, out vlrAltura)))
            {
                MessageBox.Show("Valores inválidos!");
                txtRaio.Focus(); // Focus() retorna para o txtbox selecionado
            }
            else
            {
                volume = Math.PI * Math.Pow(vlrRaio, 2) * vlrAltura; // Math.PI (número do PI), Math.Pow (faz uma potenciação)
                txtVolume.Text = volume.ToString("N2"); // ToString("N2") o N2 formata a saida, deixando apenas duas casas decimais
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close(); // Fecha a aplicação
        }
    }
}
