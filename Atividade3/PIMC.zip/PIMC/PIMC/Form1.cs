﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {

        double Peso, Altura, IMC;

        public Form1()
        {
            InitializeComponent();
            txtPeso.Text = "0";
            txtAltura.Text = "0";
            txtIMC.Text = "0";
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Peso inválido!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAltura.Focus();
            }
            else if (Peso <= 0)
            {
                MessageBox.Show("Peso não pode ser menor que 0!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAltura.Focus();
            }
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Peso inválido!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPeso.Focus();
            }
            else if (Peso <= 0)
            {
                MessageBox.Show("Peso não pode ser menor que 0!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPeso.Focus();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtIMC.Clear();
            txtPeso.Clear();
            txtMensagem.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso / Math.Pow(Altura, 2);
            IMC = Math.Round(IMC, 1);
            txtIMC.Text = IMC.ToString();

            if (IMC < 18.5)
            {
                txtMensagem.Text = "Magreza";
            }
            else if (IMC >= 18.5 && IMC <= 24.9)
            {
                txtMensagem.Text = "Normal";
            }
            else if (IMC >= 25 && IMC <= 29.9)
            {
                txtMensagem.Text = "Sobrepeso";
            }
            else if (IMC >= 30 && IMC <= 39.9)
            {
                txtMensagem.Text = "Obesidade";
            }
            else if (IMC >= 40)
            {
                txtMensagem.Text = "Obesidade Grave";
            }
        }
    } 
}
