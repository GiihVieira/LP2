﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.mskbxSbruto = new System.Windows.Forms.MaskedTextBox();
            this.nudFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblAlINSS = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAinss = new System.Windows.Forms.TextBox();
            this.txtAirpf = new System.Windows.Forms.TextBox();
            this.txtSliquido = new System.Windows.Forms.TextBox();
            this.txtSfamilia = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(47, 39);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(246, 26);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionário:";
            // 
            // lblSBruto
            // 
            this.lblSBruto.AutoSize = true;
            this.lblSBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSBruto.Location = new System.Drawing.Point(47, 97);
            this.lblSBruto.Name = "lblSBruto";
            this.lblSBruto.Size = new System.Drawing.Size(202, 26);
            this.lblSBruto.TabIndex = 1;
            this.lblSBruto.Text = "Salário Bruto R$: ";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(47, 156);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(252, 26);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Quantidade de Filhos: ";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(316, 39);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(540, 32);
            this.txtNome.TabIndex = 3;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // mskbxSbruto
            // 
            this.mskbxSbruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxSbruto.Location = new System.Drawing.Point(316, 91);
            this.mskbxSbruto.Mask = "99000.00";
            this.mskbxSbruto.Name = "mskbxSbruto";
            this.mskbxSbruto.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.mskbxSbruto.Size = new System.Drawing.Size(120, 32);
            this.mskbxSbruto.TabIndex = 4;
            this.mskbxSbruto.Validated += new System.EventHandler(this.mskbxSbruto_Validated);
            // 
            // nudFilhos
            // 
            this.nudFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudFilhos.Location = new System.Drawing.Point(316, 150);
            this.nudFilhos.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudFilhos.Name = "nudFilhos";
            this.nudFilhos.Size = new System.Drawing.Size(120, 32);
            this.nudFilhos.TabIndex = 5;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(357, 221);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(248, 53);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // lblAlINSS
            // 
            this.lblAlINSS.AutoSize = true;
            this.lblAlINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlINSS.Location = new System.Drawing.Point(47, 331);
            this.lblAlINSS.Name = "lblAlINSS";
            this.lblAlINSS.Size = new System.Drawing.Size(169, 26);
            this.lblAlINSS.TabIndex = 7;
            this.lblAlINSS.Text = "Aliquota INSS:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(47, 390);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 26);
            this.label5.TabIndex = 8;
            this.label5.Text = "Aliquota IRPF:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(47, 506);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 26);
            this.label6.TabIndex = 10;
            this.label6.Text = "Salário Liquído R$:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(47, 448);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(216, 26);
            this.label7.TabIndex = 9;
            this.label7.Text = "Salário Família R$:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(541, 387);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(217, 26);
            this.label8.TabIndex = 12;
            this.label8.Text = "Desconto IRPF R$:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(541, 328);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(219, 26);
            this.label9.TabIndex = 11;
            this.label9.Text = "Desconto INSS R$:";
            // 
            // txtAinss
            // 
            this.txtAinss.Enabled = false;
            this.txtAinss.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAinss.Location = new System.Drawing.Point(282, 326);
            this.txtAinss.Name = "txtAinss";
            this.txtAinss.Size = new System.Drawing.Size(219, 32);
            this.txtAinss.TabIndex = 13;
            // 
            // txtAirpf
            // 
            this.txtAirpf.Enabled = false;
            this.txtAirpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAirpf.Location = new System.Drawing.Point(282, 385);
            this.txtAirpf.Name = "txtAirpf";
            this.txtAirpf.Size = new System.Drawing.Size(219, 32);
            this.txtAirpf.TabIndex = 14;
            // 
            // txtSliquido
            // 
            this.txtSliquido.Enabled = false;
            this.txtSliquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSliquido.Location = new System.Drawing.Point(282, 501);
            this.txtSliquido.Name = "txtSliquido";
            this.txtSliquido.Size = new System.Drawing.Size(219, 32);
            this.txtSliquido.TabIndex = 16;
            // 
            // txtSfamilia
            // 
            this.txtSfamilia.Enabled = false;
            this.txtSfamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSfamilia.Location = new System.Drawing.Point(282, 442);
            this.txtSfamilia.Name = "txtSfamilia";
            this.txtSfamilia.Size = new System.Drawing.Size(219, 32);
            this.txtSfamilia.TabIndex = 15;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescIRPF.Location = new System.Drawing.Point(793, 381);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(133, 32);
            this.txtDescIRPF.TabIndex = 18;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescINSS.Location = new System.Drawing.Point(793, 322);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(133, 32);
            this.txtDescINSS.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 587);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSliquido);
            this.Controls.Add(this.txtSfamilia);
            this.Controls.Add(this.txtAirpf);
            this.Controls.Add(this.txtAinss);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblAlINSS);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.nudFilhos);
            this.Controls.Add(this.mskbxSbruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Folha de Pagamento";
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox mskbxSbruto;
        private System.Windows.Forms.NumericUpDown nudFilhos;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblAlINSS;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAinss;
        private System.Windows.Forms.TextBox txtAirpf;
        private System.Windows.Forms.TextBox txtSliquido;
        private System.Windows.Forms.TextBox txtSfamilia;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
    }
}

