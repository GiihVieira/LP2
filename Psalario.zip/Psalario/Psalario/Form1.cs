﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double SalarioBruto, SalarioLiquido, SalarioFamilia, DescontoINSS, DescontoIRPF;
        string AliquotaINSS, AliquotaIRPF;

        private void mskbxSbruto_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxSbruto.Text, out SalarioBruto))
            {
                MessageBox.Show("Salário Bruto inválido.");
                mskbxSbruto.Focus();
            }
            else if (SalarioBruto <= 0)
            {
                MessageBox.Show("Salário bruto não pode ser igual a 0, digite novamente por favor", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                mskbxSbruto.Focus();
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter Inválido!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Digite o Nome do Funcionário!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double filhos;
            filhos = Convert.ToDouble(nudFilhos.Text);

            // Desconto INSS
            if (SalarioBruto <= 800.47)
            {
                DescontoINSS = SalarioBruto * 0.0765;
                AliquotaINSS = "7,65%";
            }
            else if (SalarioBruto <= 1050)
            {
                DescontoINSS = SalarioBruto * 0.0865;
                AliquotaINSS = "8,65%";
            }
            else if (SalarioBruto <= 1400.77)
            {
                DescontoINSS = SalarioBruto * 0.09;
                AliquotaINSS = "9%";
            }
            else if (SalarioBruto <= 2801.56)
            {
                DescontoINSS = SalarioBruto * 0.11;
                AliquotaINSS = "11%";
            }
            else
            {
                DescontoINSS = 308.17;
                AliquotaINSS = "Teto INSS";
            }

            // Desconto IRPF
            if (SalarioBruto <= 1257.12)
            {
                DescontoIRPF = SalarioBruto * 0;
                AliquotaIRPF = "Isento";
            }
            else if (SalarioBruto <= 2512.08)
            {
                DescontoIRPF = SalarioBruto * 0.15;
                AliquotaIRPF = "15%";
            }
            else
            {
                DescontoIRPF = SalarioBruto * 0.275;
                AliquotaIRPF = "27,5%";
            }

            // Salário Família
            if (SalarioBruto <= 435.52)
            {
                SalarioFamilia = 22.33 * filhos;
            }
            else if (SalarioBruto <= 654.61)
            {
                SalarioFamilia = 15.74 * filhos;
            }
            else
            {
                SalarioFamilia = 0;
            }

            // Salário Liquído
            SalarioLiquido = SalarioBruto - DescontoINSS - DescontoIRPF + SalarioFamilia;

            // Saídas
            txtDescINSS.Text = DescontoINSS.ToString("N2");
            txtDescIRPF.Text = DescontoIRPF.ToString("N2");
            txtAinss.Text = AliquotaINSS;
            txtAirpf.Text = AliquotaIRPF;
            txtSliquido.Text = SalarioLiquido.ToString("N2");
            txtSfamilia.Text = SalarioFamilia.ToString("N2");

        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
