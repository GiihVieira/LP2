namespace PTesteLoop
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sariToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exerc�cio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Verifica se o form1 foi aberto
            if (Application.OpenForms.OfType<frmExercicio1>().Count() > 0)
            {
                // Chama o Form frmExercicio1 para a frente
                Application.OpenForms["frmExercicio1"].BringToFront();
            }
            else
            {
                frmExercicio1 objfrm1 = new frmExercicio1();
                objfrm1.MdiParent = this; // Deixa o form1 ancorado no form Principal
                objfrm1.WindowState = FormWindowState.Maximized;
                objfrm1.Show();
            }
        }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                // Chama o Form frmExercicio2 para a frente
                Application.OpenForms["frmExercicio2"].BringToFront();
            }
            else
            {
                frmExercicio2 objfrm2 = new frmExercicio2();
                objfrm2.MdiParent = this; // Deixa o form2 ancorado no form Principal
                objfrm2.WindowState = FormWindowState.Maximized;
                objfrm2.Show();
            }
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                // Chama o Form frmExercicio3 para a frente
                Application.OpenForms["frmExercicio3"].BringToFront();
            }
            else
            {
                frmExercicio3 objfrm3 = new frmExercicio3();
                objfrm3.MdiParent = this; // Deixa o form3 ancorado no form Principal
                objfrm3.WindowState = FormWindowState.Maximized;
                objfrm3.Show();
            }
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                // Chama o Form frmExercicio4 para a frente
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 objfrm4 = new frmExercicio4();
                objfrm4.MdiParent = this; // Deixa o form4 ancorado no form Principal
                objfrm4.WindowState = FormWindowState.Maximized;
                objfrm4.Show();
            }
        }

        private void exerc�cio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                // Chama o Form frmExercicio5 para a frente
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 objfrm5 = new frmExercicio5();
                objfrm5.MdiParent = this; // Deixa o form5 ancorado no form Principal
                objfrm5.WindowState = FormWindowState.Maximized;
                objfrm5.Show();
            }
        }
    }
}
