﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PTesteLoop
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string saida = "";
            ArrayList Alunos = new ArrayList { "Ana" , "André", "Débora",
                                             "João", "Janete", "Otávio",
                                             "Marcelo", "Pedro", "Thais" };

            Alunos.Remove("Otávio");

            for (int i = 0; i < Alunos.Count; i++)
            {
                if (i != Alunos.Count - 1)
                {
                    saida = saida + Alunos[i] + ", ";
                }
                else
                {
                    saida = saida + Alunos[i];
                }
            }

            MessageBox.Show($"Lista de Alunos sem o aluno Otávio: {saida}");
        }
    }
}
