﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteLoop
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();

            int numeroEntrada;
            string[] numeros = new string[20];
            string saida = "";

            for (int i = 0; i < numeros.Length; i++)
            {
                if (!int.TryParse(Interaction.InputBox("Digite um número: ", "Reverter Sequência Númerica"),
                    out numeroEntrada))
                {
                    MessageBox.Show("Digite um número válido!");
                    i--;
                }
                else
                {
                    numeros[i] = numeroEntrada.ToString();
                }
            }

            Array.Reverse(numeros);

            for (int i = 0; i < numeros.Length; i++)
            {
                if (i != numeros.Length - 1)
                {
                    saida = saida + numeros[i] + ", ";
                }
                else
                {
                    saida = saida + numeros[i];
                }
            }

            MessageBox.Show($"Sequência de Números Inversa: {saida}");
        }
    }
}
