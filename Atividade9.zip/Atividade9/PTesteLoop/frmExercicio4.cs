﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteLoop
{
    public partial class frmExercicio4 : Form
    {

        string[] nomes = new string[3];
        string saida;
        int somaLetras;
        public frmExercicio4()
        {
            InitializeComponent();


            for (int i = 0; i < nomes.Length; i++)
            {
                nomes[i] = Interaction.InputBox("Digite o nome completo: ", "Nomes");
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            foreach (string nome in nomes)
            {
                somaLetras = 0;
                saida = "";
                foreach (char c in nome)
                {
                    if (char.IsLetter(c))
                    {
                        somaLetras++;
                    }
                }
                saida = $"O nome: {nome} tem {somaLetras} letras \n";
                lstBox.Items.Add(saida);
            }
        }
    }
}
