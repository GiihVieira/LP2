﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteLoop
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();

            string saida = "";
            double nota, soma;
            double[,] notasAlunos = new double[3, 20];
            double[] mediaAlunos = new double[20];

            // Entrada das notas de cada aluno e gera as médias
            for (int i = 0; i < 20; i++)
            {
                soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    if (!Double.TryParse(Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ", "Médias dos Alunos"),
                        out nota) || nota > 10 || nota < 0)
                    {
                        MessageBox.Show("Digite uma nota válida!");
                        j--;
                    }
                    else
                    {
                        soma += nota;
                        notasAlunos[j, i] = nota; 
                    }
                }
                mediaAlunos[i] = soma / 3;
            }

            // Print de saída
            for (int i = 0; i < 20; i++)
            {
                saida += $"Aluno {i +1}, média: {mediaAlunos[i].ToString("N1")} \n";
            }

            MessageBox.Show(saida);
        }
    }
}
