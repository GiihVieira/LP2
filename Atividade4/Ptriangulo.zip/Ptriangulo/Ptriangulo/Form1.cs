namespace Ptriangulo
{
    public partial class Form1 : Form
    {

        double lA, lB, lC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out lA) || txtLadoA.Text == "")
            { 
                MessageBox.Show("Lado A Incorreto ou V�zio");
                txtLadoA.Focus();
            }
            else if (lA <= 0)
            {
                MessageBox.Show("Lado A n�o pode ser 0");
                txtLadoA.Focus();
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out lB) || txtLadoB.Text == "")
            {
                MessageBox.Show("Lado B Incorreto ou V�zio");
                txtLadoA.Focus();
            }
            else if (lB <= 0)
            {
                MessageBox.Show("Lado B n�o pode ser 0");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out lC) || txtLadoC.Text == "")
            {
                MessageBox.Show("Lado C Incorreto ou V�zio");
                txtLadoC.Focus();
            }
            else if (lC <= 0)
            {
                MessageBox.Show("Lado C n�o pode ser 0");
                txtLadoC.Focus();
            }
        }

        private void btnAnalisar_Click(object sender, EventArgs e)
        {
            // Verifica se � possivel formar um tri�ngulo
            if ((lA > Math.Abs(lB - lC) && lA < (lB + lC)) && 
                (lB > Math.Abs(lA - lC) && lB < (lA + lC)) &&
                (lC > Math.Abs(lA - lB) && lC < (lA + lB)))     
            {
                if (lA == lB && lA == lC && lB == lC) // Todos os lado iguais
                {
                    txtMensagem.Text = "Equil�tero";
                }
                else if (lA != lB && lA != lC && lB != lC) // Todos os lados diferentes
                {
                    txtMensagem.Text = "Escaleno";
                }
                else // Pelo menos um dos lados iguais
                {
                    txtMensagem.Text = "Is�sceles";
                }
            }
            else
            {
                MessageBox.Show("N�o � poss�vel formar um tri�ngulo com essas medidas.");
            }
        }
    }
}
