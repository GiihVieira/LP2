﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLadoA = new Label();
            lblLadoB = new Label();
            lblLadoC = new Label();
            txtLadoA = new TextBox();
            txtLadoB = new TextBox();
            txtLadoC = new TextBox();
            lblMensagem = new Label();
            txtMensagem = new TextBox();
            btnAnalisar = new Button();
            SuspendLayout();
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLadoA.Location = new Point(68, 74);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(82, 28);
            lblLadoA.TabIndex = 0;
            lblLadoA.Text = "Lado A:";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLadoB.Location = new Point(68, 127);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(81, 28);
            lblLadoB.TabIndex = 1;
            lblLadoB.Text = "Lado B:";
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLadoC.Location = new Point(68, 180);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(80, 28);
            lblLadoC.TabIndex = 2;
            lblLadoC.Text = "Lado C:";
            // 
            // txtLadoA
            // 
            txtLadoA.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtLadoA.Location = new Point(156, 67);
            txtLadoA.Name = "txtLadoA";
            txtLadoA.Size = new Size(125, 34);
            txtLadoA.TabIndex = 3;
            txtLadoA.Validated += txtLadoA_Validated;
            // 
            // txtLadoB
            // 
            txtLadoB.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtLadoB.Location = new Point(156, 121);
            txtLadoB.Name = "txtLadoB";
            txtLadoB.Size = new Size(125, 34);
            txtLadoB.TabIndex = 4;
            txtLadoB.Validated += txtLadoB_Validated;
            // 
            // txtLadoC
            // 
            txtLadoC.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtLadoC.Location = new Point(156, 174);
            txtLadoC.Name = "txtLadoC";
            txtLadoC.Size = new Size(125, 34);
            txtLadoC.TabIndex = 5;
            txtLadoC.Validated += txtLadoC_Validated;
            // 
            // lblMensagem
            // 
            lblMensagem.AutoSize = true;
            lblMensagem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMensagem.Location = new Point(343, 71);
            lblMensagem.Name = "lblMensagem";
            lblMensagem.Size = new Size(169, 28);
            lblMensagem.TabIndex = 6;
            lblMensagem.Text = "Esse Triângulo é:";
            // 
            // txtMensagem
            // 
            txtMensagem.Enabled = false;
            txtMensagem.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtMensagem.Location = new Point(362, 111);
            txtMensagem.Name = "txtMensagem";
            txtMensagem.Size = new Size(125, 34);
            txtMensagem.TabIndex = 7;
            txtMensagem.TextAlign = HorizontalAlignment.Center;
            // 
            // btnAnalisar
            // 
            btnAnalisar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAnalisar.Location = new Point(206, 239);
            btnAnalisar.Name = "btnAnalisar";
            btnAnalisar.Size = new Size(176, 42);
            btnAnalisar.TabIndex = 8;
            btnAnalisar.Text = "Análisar";
            btnAnalisar.UseVisualStyleBackColor = true;
            btnAnalisar.Click += btnAnalisar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(559, 311);
            Controls.Add(btnAnalisar);
            Controls.Add(txtMensagem);
            Controls.Add(lblMensagem);
            Controls.Add(txtLadoC);
            Controls.Add(txtLadoB);
            Controls.Add(txtLadoA);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoA);
            Name = "Form1";
            Text = "Análisador de Triângulos";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoA;
        private Label lblLadoB;
        private Label lblLadoC;
        private TextBox txtLadoA;
        private TextBox txtLadoB;
        private TextBox txtLadoC;
        private Label lblMensagem;
        private TextBox txtMensagem;
        private Button btnAnalisar;
    }
}
