﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
            int qtdNumeros = 0;
            
            foreach(char ch in rchtxtTexto.Text)
            {
                if (char.IsDigit(ch))
                {
                    qtdNumeros++;
                }
            }
            MessageBox.Show($"Total de Números: {qtdNumeros}");
        }

        private void btnVazio_Click(object sender, EventArgs e)
        {
            int vazio = 0;
            char[] texto = rchtxtTexto.Text.ToCharArray();

            for (int i = 0; i < rchtxtTexto.TextLength; i++)
            {
                if (char.IsWhiteSpace(texto[i]))
                {
                    vazio++;
                }
            }
            MessageBox.Show($"Total de Espaços em Branco: {vazio}");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int qtdLetras = 0;

            foreach (char ch in rchtxtTexto.Text)
            {
                if (char.IsLetter(ch))
                {
                    qtdLetras++;
                }
            }
            MessageBox.Show($"Total de Letras: {qtdLetras}");
        }
    }
}
